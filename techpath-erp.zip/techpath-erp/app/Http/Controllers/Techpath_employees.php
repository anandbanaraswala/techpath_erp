<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\Employees;
use App\Models\Techpath_bank_info_model;
use App\Models\Tech_path_family_info_model;
use App\Models\Techpath_education_info_model;
use App\Models\Techpath_emergency_contact_model;
use App\Models\Techpath_experience_info_model;
use App\Models\Techpath_personal_information_model;


class Techpath_employees extends Controller
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(),[
            'TechpathErpEmployeeFirstName' => 'required|min:1|max:150',
            'TechpathErpEmployeeLastName' => 'required|min:1|max:150',
            'TechpathErpEmployeeUsername' => 'required|min:1|max:150',
            'TechpathErpEmployeeEmail' => 'required|email|max:150',
            'TechpathErpEmployeePassword' => 'required|min:1|max:25',
            'TechpathErpEmployeeEmployeeId' => 'required|min:1|max:25',
            'TechpathErpEmployeeJoiningDate' =>	'required',
            'TechpathErpEmployeePhone' => 'required|min:1|max:25',
            'TechpathErpEmployeeCompany' => 'required|min:1|max:25',
            'TechpathErpEmployeeDepartment' => 'required|min:1|max:150',
            'TechpathErpEmployeeDesignation' => 'required|min:1|max:150'
        ]);

        if($validator->fails())
        {
            return response()->json([
                'messages' => 'All input field are required'
            ],500);
        }
        else
        {
            try
            {
                $employees_insert = new Employees();
                $employees_insert->TechpathErpEmployeeFirstName = $request->TechpathErpEmployeeFirstName;
                $employees_insert->TechpathErpEmployeeLastName = $request->TechpathErpEmployeeLastName;
                $employees_insert->TechpathErpEmployeeUsername = $request->TechpathErpEmployeeUsername;
                $employees_insert->TechpathErpEmployeeEmail = $request->TechpathErpEmployeeEmail;
                $employees_insert->TechpathErpEmployeePassword = bcrypt($request->TechpathErpEmployeePassword);
                $employees_insert->TechpathErpEmployeeEmployeeId = $request->TechpathErpEmployeeEmployeeId;
                $employees_insert->TechpathErpEmployeeJoiningDate = $request->TechpathErpEmployeeJoiningDate;
                $employees_insert->TechpathErpEmployeePhone = $request->TechpathErpEmployeePhone;
                $employees_insert->TechpathErpEmployeeCompany = $request->TechpathErpEmployeeCompany;
                $employees_insert->TechpathErpEmployeeDepartment = $request->TechpathErpEmployeeDepartment;
                $employees_insert->TechpathErpEmployeeDesignation = $request->TechpathErpEmployeeDesignation;
                $employees_insert->save();
                return response(array("message"=>"Success !"),200)->header("Content-Type","application/json");
            }

            catch(\Exception $e)
            {
                return response(array("message"=>"Duplicate Entry"),409)->header("Content-Type","application/json");
            }

        }
    }

    public function insert_bank_info(Request $request)
    {
        $validator = Validator::make($request->all(),[
            'TechpathErpEmployeeId' => 'required|min:1|max:150',
            'BankInfoBankName' => 'required|min:1|max:191',
            'BankInfoBankAccountNum' => 'required|min:1|max:150',
            'BankInfoIfscCode' => 'required|min:1|max:150',
            'BankInfoPanCardNum' => 'required|min:1|max:25'
        ]);

        if($validator->fails())
        {
            return response()->json([
                'messages' => 'All input fields are required'
            ],500);
        }
        else
        {
            try
            {
                $bank_info_insert = new Techpath_bank_info_model();
                $bank_info_insert->TechpathErpEmployeeId = $request->TechpathErpEmployeeId;
                $bank_info_insert->BankInfoBankName = $request->BankInfoBankName;
                $bank_info_insert->BankInfoBankAccountNum = $request->BankInfoBankAccountNum;
                $bank_info_insert->BankInfoIfscCode = $request->BankInfoIfscCode;
                $bank_info_insert->BankInfoPanCardNum = $request->BankInfoPanCardNum;
                $bank_info_insert->save();
                return response(array("message"=>"Success !"),200)->header("Content-Type","application/json");
            }

            catch(\Exception $e)
            {
                return response(array("message"=>"Duplicate entry !"),409)->header("Content-Type","application/json");
            }
        }
    }

    public function emergency_contact_store(Request $request)
    {
        $validator = Validator::make($request->all(),[
            'TechpathErpEmployeeId' => 'required|min:1|max:191',
            'EmergencyContactPrimaryName' => 'required|min:1|max:191',
            'EmergencyContactPrimaryRelationship' => 'required|min:1|max:150',
            'EmergencyContactPrimaryPhone' => 'required|min:1|max:15',
            'EmergencyContactSecondaryName' => 'required|min:1|max:150',
            'EmergencyContactSecondaryRelationship' => 'required|min:1|max:150',
            'EmergencyContactSecondaryPhone' => 'required|min:1|max:15'
        ]);

        if($validator->fails())
        {
            return response()->json([
                // 'messages' => $validator->messages() // important this return what types of error have occured
                'message' => "All input field are required"
            ],500);
        }

        else
        {
            try
            {
                $bank_emergency_insert = new Techpath_emergency_contact_model();
                $bank_emergency_insert->TechpathErpEmployeeId = $request->TechpathErpEmployeeId;
                $bank_emergency_insert->EmergencyContactPrimaryName = $request->EmergencyContactPrimaryName;
                $bank_emergency_insert->EmergencyContactPrimaryRelationship = $request->EmergencyContactPrimaryRelationship;
                $bank_emergency_insert->EmergencyContactPrimaryPhone = $request->EmergencyContactPrimaryPhone;
                $bank_emergency_insert->EmergencyContactSecondaryName = $request->EmergencyContactSecondaryName;
                $bank_emergency_insert->EmergencyContactSecondaryRelationship = $request->EmergencyContactSecondaryRelationship;
                $bank_emergency_insert->EmergencyContactSecondaryPhone = $request->EmergencyContactSecondaryPhone;
                $bank_emergency_insert->save();
                return response(array("message"=>"Success !"),200)->header("Content-Type","application/json");
            }

            catch(\Exception $e)
            {
                return response(array("message"=>"Duplicate entry !"),409)->header("Content-Type","application/json");
            }

        }
    }

    public function personal_information_store(Request $request)
    {
        $validator = Validator::make($request->all(),[
            'TechpathErpEmployeeId' => 'required|min:1|max:191',
            'PerInfPassportNum' => 'required|min:1|max:191',
            'PerInfPassportExpDate' => 'required',
            'PerInfEmployeeTel' => 'required|min:1|max:15',
            'PerInfNationality' => 'required|min:1|max:150',
            'PerInfMartialStatus' => 'required|min:1|max:150',
            'PerInfEmployeeOfSpouse' => 'required|min:1|max:50',
            'PerInfChildren' => 'required|min:1|max:100',
            'PerInfoPhoto' => 'required'
        ]);

        if($validator->fails())
        {
            return response()->json([
                // 'messages' => $validator->messages() // important this return what types of error have occured
                'message' => "All input field are required"
            ],500);
        }

        else
        {
            try
            {
                $bank_personal_info_insert = new Techpath_personal_information_model();
                $bank_personal_info_insert->TechpathErpEmployeeId = $request->TechpathErpEmployeeId;
                $bank_personal_info_insert->PerInfPassportNum = $request->PerInfPassportNum;
                $bank_personal_info_insert->PerInfPassportExpDate = $request->PerInfPassportExpDate;
                $bank_personal_info_insert->PerInfEmployeeTel = $request->PerInfEmployeeTel;
                $bank_personal_info_insert->PerInfNationality = $request->PerInfNationality;
                $bank_personal_info_insert->PerInfMartialStatus = $request->PerInfMartialStatus;
                $bank_personal_info_insert->PerInfEmployeeOfSpouse = $request->PerInfEmployeeOfSpouse;
                $bank_personal_info_insert->PerInfChildren = $request->PerInfChildren;
                $bank_personal_info_insert->PerInfoPhoto = $request->PerInfoPhoto;
                $bank_personal_info_insert->save();
                return response(array("message"=>"Success"),200)->header("Content-Type","application/json");
            }

            catch(\Exception $e)
            {
                return response(array("message"=>"Duplicate entry !"),409)->header("Content-Type","application/json");
            }
        }
    }

    public function insert_education_info(Request $request)
    {
        $validator = Validator::make($request->all(),[
            'TechpathErpEmployeeId' => 'required|min:1|max:191',
            'EducationInfoInstitutionName' => 'required|min:1|max:191',
            'EducationInfoSubjectName' => 'required|min:1|max:150',
            'EducationInfoStartingDate' => 'required',
            'EducationInfoCompleteDate' => 'required',
            'EducationInfoDegree' => 'required|min:1|max:191',
            'EducationInfoGrade' => 'required|min:1|max:191'
        ]);

        if($validator->fails())
        {
            return response()->json([
                // 'messages' => $validator->messages() // important this return what types of error have occured
                'message' => "All input field are required"
            ],500);
        }

        else
        {
            try
            {
                $education_info__insert = new Techpath_education_info_model();
                $education_info__insert->TechpathErpEmployeeId = $request->TechpathErpEmployeeId;
                $education_info__insert->EducationInfoInstitutionName = $request->EducationInfoInstitutionName;
                $education_info__insert->EducationInfoSubjectName = $request->EducationInfoSubjectName;
                $education_info__insert->EducationInfoStartingDate = $request->EducationInfoStartingDate;
                $education_info__insert->EducationInfoCompleteDate = $request->EducationInfoCompleteDate;
                $education_info__insert->EducationInfoDegree = $request->EducationInfoDegree;
                $education_info__insert->EducationInfoGrade = $request->EducationInfoGrade;
                $education_info__insert->save();
                return response(array("message"=>"success"),200)->header("Content-Type","application/json");
            }

            catch(\Exception $e)
            {
                return response(array("message"=>"Duplicate entry !"),409)->header("Content-Type","application/json");
            }

        }
    }

    public function insert_experience_info(Request $request)
    {
        $validator = Validator::make($request->all(),[
            'TechpathErpEmployeeId' => 'required|min:1|max:11',
            'ExperienceInfoCompanyName' => 'required|min:1|max:191',
            'ExperienceInfoLocation' => 'required',
            'ExperienceInfoJobPosition' => 'required',
            'ExperienceInfoPeriodFrom' => 'required',
            'ExperienceInfoPeriodTo' => 'required'
        ]);

        if($validator->fails())
        {
            return response()->json([
                //'messages' => $validator->messages() // important this return what types of error have occured
                'message' => "All input fields are required"
            ],500);
        }

        else
        {
            try
            {
                $experience_info_insert = new Techpath_experience_info_model();
                $experience_info_insert->TechpathErpEmployeeId = $request->TechpathErpEmployeeId;
                $experience_info_insert->ExperienceInfoCompanyName = $request->ExperienceInfoCompanyName;
                $experience_info_insert->ExperienceInfoLocation = $request->ExperienceInfoLocation;
                $experience_info_insert->ExperienceInfoJobPosition = $request->ExperienceInfoJobPosition;
                $experience_info_insert->ExperienceInfoPeriodFrom = $request->ExperienceInfoPeriodFrom;
                $experience_info_insert->ExperienceInfoPeriodTo = $request->ExperienceInfoPeriodTo;
                $experience_info_insert->save();
                return response(array("message"=>"success"),200)->header("Content-Type","application/json");
            }
            catch(\Exception $e)
            {
                return response(array("message"=>"Duplicate entry !"),409)->header("Content-Type","application/json");
            }

        }
    }

    public function insert_family_info(Request $request)
    {
        $validator = Validator::make($request->all(),[
            'TechpathErpEmployeeId' => 'required|min:1|max:150',
            'FamilyInfoName' => 'required|min:1|max:191',
            'FamilyInfoRelationship' => 'required|min:1|max:150',
            'FamilyInfoDob' => 'required',
            'FamilInfoPhone' => 'required'
        ]);

        if($validator->fails())
        {
            return response()->json([
                'messages' => 'All input fields are required'
            ],500);
        }
        else
        {
           try
            {
                $family_info_insert = new Tech_path_family_info_model();
                $family_info_insert->TechpathErpEmployeeId = $request->TechpathErpEmployeeId;
                $family_info_insert->FamilyInfoName = $request->FamilyInfoName;
                $family_info_insert->FamilyInfoRelationship = $request->FamilyInfoRelationship;
                $family_info_insert->FamilyInfoDob = $request->FamilyInfoDob;
                $family_info_insert->FamilInfoPhone = $request->FamilInfoPhone;
                $family_info_insert->save();
                return response(array("message"=>"Success !"),200)->header("Content-Type","application/json");
            }
            catch(\Exception $e)
            {
                return response(array("message"=>"Duplicate entry !"),409)->header("Content-Type","application/json");
            }
        }
    }


}
