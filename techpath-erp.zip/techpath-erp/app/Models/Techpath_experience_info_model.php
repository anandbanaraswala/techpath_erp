<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Techpath_experience_info_model extends Model
{
    use HasFactory;
    protected $primaryKey = 'ExperienceInfoId';
    protected $table = 'tech_path_experience_info';

    protected $fillable = [
        'TechpathErpEmployeeId',
        'ExperienceInfoCompanyName',
        'ExperienceInfoLocation',
        'ExperienceInfoJobPosition',
        'ExperienceInfoPeriodFrom',
        'ExperienceInfoPeriodTo'
    ];
}
