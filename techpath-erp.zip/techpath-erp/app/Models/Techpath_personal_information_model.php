<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Techpath_personal_information_model extends Model
{
    use HasFactory;
    protected $primaryKey = 'PersonalInformationId';
    protected $table = 'techpath_personal_information';

    protected $fillable = [
        'TechpathErpEmployeeId',
        'PerInfPassportNum',
        'PerInfPassportExpDate',
        'PerInfEmployeeTel',
        'PerInfNationality',
        'PerInfMartialStatus',
        'PerInfEmployeeOfSpouse',
        'PerInfChildren',
        'PerInfoPhoto'
    ];
}
