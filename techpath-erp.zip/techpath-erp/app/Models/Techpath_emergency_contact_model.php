<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Techpath_emergency_contact_model extends Model
{
    use HasFactory;
    protected $primaryKey = 'EmergencyContactId';
    protected $table = 'techpath_emergency_contact';

    protected $fillable = [
        'TechpathErpEmployeeId',
        'EmergencyContactPrimaryName',
        'EmergencyContactPrimaryRelationship',
        'EmergencyContactPrimaryPhone',
        'EmergencyContactSecondaryName',
        'EmergencyContactSecondaryRelationship',
        'EmergencyContactSecondaryPhone'
    ];
}
