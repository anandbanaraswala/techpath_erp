<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Employees extends Model
{
    use HasFactory;
    protected $primaryKey = 'TechpathErpEmployeeId';
    protected $table = 'techpath_employees';
    protected $fillable = [
        'TechpathErpEmployeeId',
        'TechpathErpEmployeeFirstName',
        'TechpathErpEmployeeLastName',
        'TechpathErpEmployeeUsername',
        'TechpathErpEmployeeEmail',
        'TechpathErpEmployeePassword',
        'TechpathErpEmployeeEmployeeId',
        'TechpathErpEmployeeJoiningDate',
        'TechpathErpEmployeePhone',
        'TechpathErpEmployeeCompany',
        'TechpathErpEmployeeDepartment',
        'TechpathErpEmployeeDesignation'
    ];
}
