<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Techpath_education_info_model extends Model
{
    use HasFactory;
    protected $primaryKey = 'FamilyInfoId';
    protected $table = 'tech_path_education_info';

    protected $fillable = [
        'TechpathErpEmployeeId',
        'EducationInfoInstitutionName',
        'EducationInfoSubjectName',
        'EducationInfoStartingDate',
        'EducationInfoCompleteDate',
        'EducationInfoDegree',
        'EducationInfoGrade'
    ];
}
