<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Tech_path_family_info_model extends Model
{
    use HasFactory;
    protected $primaryKey = 'FamilyInfoId';
    protected $table = 'tech_path_family_info';
    protected $fillable = [
        'TechpathErpEmployeeId',
        'FamilyInfoName',
        'FamilyInfoRelationship',
        'FamilyInfoDob',
        'FamilInfoPhone'
    ];
}
