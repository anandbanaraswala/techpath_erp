<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Techpath_bank_info_model extends Model
{
    use HasFactory;
    protected $primaryKey = 'BankInfoId';
    protected $table = 'techpath_bank_info';

    protected $fillable = [
        'TechpathErpEmployeeId',
        'BankInfoBankName',
        'BankInfoBankAccountNum',
        'BankInfoIfscCode',
        'BankInfoPanCardNum'
    ];
}
