<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateBankInfoTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('techpath_bank_info', function (Blueprint $table) {
            $table->increments('BankInfoId');
            $table->bigInteger('TechpathErpEmployeeId')->unique();
            $table->foreign('TechpathErpEmployeeId')->references('TechpathErpEmployeeId')->on('techpath_employees');
            $table->string('BankInfoBankName')->default('NULL');
            $table->string('BankInfoBankAccountNum')->unique();
            $table->string('BankInfoIfscCode')->default("NULL");
            $table->string('BankInfoPanCardNum')->unique();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('bank_info');
    }
}
