<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTechEmployeesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('techpath_employees', function (Blueprint $table) {
            $table->increments('TechpathErpEmployeeId');
            $table->string('TechpathErpEmployeeFirstName',150)->default('NULL');
            $table->string('TechpathErpEmployeeLastName',150)->default('NULL');
            $table->string('TechpathErpEmployeeUsername',150)->default('NULL');
            $table->string('TechpathErpEmployeeEmail',150)->unique();
            $table->string('TechpathErpEmployeePassword');
            $table->string('TechpathErpEmployeeEmployeeId')->unique();
            $table->date('TechpathErpEmployeeJoiningDate');
            $table->string('TechpathErpEmployeePhone')->unique();
            $table->string('TechpathErpEmployeeCompany')->default('NULL');
            $table->string('TechpathErpEmployeeDepartment')->default('NULL');
            $table->string('TechpathErpEmployeeDesignation')->default('NULL');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tech_employees');
    }
}
