<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTechPathEducationInfoTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tech_path_education_info', function (Blueprint $table) {
            $table->increments('FamilyInfoId');
            $table->integer('TechpathErpEmployeeId');
            $table->foreign('TechpathErpEmployeeId')->references('TechpathErpEmployeeId')->on('techpath_employees');
            $table->string('EducationInfoInstitutionName');
            $table->string('EducationInfoSubjectName');
            $table->date('EducationInfoStartingDate');
            $table->date('EducationInfoCompleteDate');
            $table->string('EducationInfoDegree');
            $table->string('EducationInfoGrade');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tech_path_education_info');
    }
}
