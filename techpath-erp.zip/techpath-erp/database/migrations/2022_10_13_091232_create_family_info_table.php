<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateFamilyInfoTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tech_path_family_info', function (Blueprint $table) {
            $table->increments('FamilyInfoId');
            $table->bigInteger('TechpathErpEmployeeId')->unique();
            $table->foreign('TechpathErpEmployeeId')->references('TechpathErpEmployeeId')->on('techpath_employees');
            $table->string('FamilyInfoName');
            $table->string('FamilyInfoRelationship');
            $table->date('FamilyInfoDob');
            $table->string('FamilInfoPhone')->unique();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('family_info');
    }
}
