<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTechpathEmergencyContactTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('techpath_emergency_contact', function (Blueprint $table) {
            $table->increments('EmergencyContactId');
            $table->bigInteger('TechpathErpEmployeeId')->unique();
            $table->foreign('TechpathErpEmployeeId')->references('TechpathErpEmployeeId')->on('techpath_employees');
            $table->string('EmergencyContactPrimaryName')->default("NULL");
            $table->string('EmergencyContactPrimaryRelationship')->default("NULL");
            $table->string('EmergencyContactPrimaryPhone')->unique();
            $table->string('EmergencyContactSecondaryName')->default("NULL");
            $table->string('EmergencyContactSecondaryRelationship')->default("NULL");
            $table->string('EmergencyContactSecondaryPhone')->unique();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('techpath_emergency_contact');
    }
}
