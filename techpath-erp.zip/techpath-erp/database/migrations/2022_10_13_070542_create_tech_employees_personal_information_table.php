<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTechEmployeesPersonalInformationTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('techpath_personal_information', function (Blueprint $table) {
            $table->increments('PersonalInformationId');
            $table->bigInteger('TechpathErpEmployeeId')->unique();
            $table->foreign('TechpathErpEmployeeId')->references('TechpathErpEmployeeId')->on('techpath_employees');
            $table->string('PerInfPassportNum')->unique();
            $table->date('PerInfPassportExpDate');
            $table->string('PerInfEmployeeTel')->unique();
            $table->string('PerInfNationality');
            $table->string('PerInfMartialStatus');
            $table->string('PerInfEmployeeOfSpouse');
            $table->integer('PerInfChildren');
            $table->string('PerInfoPhoto');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tech_employees_personal_information');
    }
}
