<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTechPathExperienceInfoTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tech_path_experience_info', function (Blueprint $table) {
            $table->increments('ExperienceInfoId');
            $table->bigInteger('TechpathErpEmployeeId');
            $table->foreign('TechpathErpEmployeeId')->references('TechpathErpEmployeeId')->on('techpath_employees');
            $table->string('ExperienceInfoCompanyName');
            $table->string('ExperienceInfoLocation');
            $table->string('ExperienceInfoJobPosition');
            $table->date('ExperienceInfoPeriodFrom');
            $table->date('ExperienceInfoPeriodTo');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tech_path_experience_info');
    }
}
