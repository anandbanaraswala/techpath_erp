<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use  App\Http\Controllers\Techpath_employees;
/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

Route::post('employee-registration',[App\Http\Controllers\Techpath_employees::class,'store']);

Route::post('insert-employee-bank-info',[App\Http\Controllers\Techpath_employees::class,'insert_bank_info']);

Route::post('insert-employee-emergency-contact',[App\Http\Controllers\Techpath_employees::class,'emergency_contact_store']);

Route::post('insert-employee-personal-info',[App\Http\Controllers\Techpath_employees::class,'personal_information_store']);

Route::post('insert-employee-education-info',[App\Http\Controllers\Techpath_employees::class,'insert_education_info']);

Route::post('insert-employee-experience-info',[App\Http\Controllers\Techpath_employees::class,'insert_experience_info']);

Route::post('insert-family-info',[App\Http\Controllers\Techpath_employees::class,'insert_family_info']);
